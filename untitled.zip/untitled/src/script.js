function openCase() {

  const loginPage = document.getElementById("loginPage");
  const casePage = document.getElementById("casePage");

  loginPage.style.opacity = "0";
  loginPage.style.transform = "scale(0.96)";

  setTimeout(() => {

    loginPage.classList.add("hidden");

    casePage.classList.remove("hidden");

    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });

    revealDocuments();

  }, 500);
}


function revealDocuments() {

  const documents = document.querySelectorAll(
    ".document, .evidence, .final-evidence, .verdict"
  );

  const observer = new IntersectionObserver(
    (entries) => {

      entries.forEach((entry) => {

        if (entry.isIntersecting) {
          entry.target.classList.add("show");
        }

      });

    },
    {
      threshold: 0.15
    }
  );

  documents.forEach((document) => {
    observer.observe(document);
  });
}